
def potencia(op1,op2):
	print("El resultado de la es: ", op1 ** op2)

def redondear(numero):

	print("El resultado es: ", round(numero))