from setuptools import setup


setup(

	name="paquete_Calculos",
	version="1.0",
	description="Paquete de redonde y potencia",
	author="Carlos",
	packages=["Calculos_paquete","Calculos_paquete.redondeo_potencia"]

	)
